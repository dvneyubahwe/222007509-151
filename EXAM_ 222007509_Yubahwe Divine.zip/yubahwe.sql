-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 09:07 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yubahwe`
--

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE `family` (
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `idnumber` varchar(50) NOT NULL,
  `phonenumber` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `family2`
--

CREATE TABLE `family2` (
  `firstname` varchar(50) NOT NULL,
  `secondname` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family2`
--

INSERT INTO `family2` (`firstname`, `secondname`, `country`, `username`, `password`, `email`) VALUES
('', '', '', '', '', ''),
('dd', 'dd', 'dd', 'dd', 'dd', 'dd'),
('ff', 'ff', 'ff', 'ff', 'ff', 'ff'),
('tt', 'tt', 'tt', 'tt', 'tt', 'tt'),
('mugabo', 'samuel', 'rwanda', 'chr ', 'divine', 'eety@fhjk'),
('ss', 'bbj', 'vbhj', 'yy', 'yy', 'dsrtryu'),
('mm', 'mm', 'mm', 'mm', 'mm', 'mm'),
('yubahwe', 'divine', 'rwanda', 'sally', 'samuel', 'dfdhfgjhkjlk'),
('hh', 'hh', 'hh', 'hh', 'hh', 'hh'),
('hh', 'hh', 'hh', 'hh', 'hh', 'hh'),
('hh', 'hh', 'hh', 'hh', 'hh', 'hh');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
